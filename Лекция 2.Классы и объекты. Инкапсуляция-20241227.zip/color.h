enum class Color
{
    BLACK,
    RED,
    GREEN,
    BLUE,
    GRAY,
    WHITE,
    COUNT
};
